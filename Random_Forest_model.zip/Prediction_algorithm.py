from sklearn.ensemble import RandomForestClassifier
import scipy.io
import numpy as np
import pickle
filename = 'Forest_model.sav'
loaded_model = pickle.load(open(filename, 'rb'))
print ('Welcome to the prediction tool: please use the point as separator for decimal number: (3.7 and not 3,7)')
print ('-------------------------\n')
ABPM_parameters = ['Aldosterone at screening [ng/dL]',
        'Lowest Potassium [mEq/L]',
        'Aldosterone post-confirmatory test [ng/dL]',
        'Presence of nodule at CT scanning [Yes/No]',
        'Diameter of the Largest Nodule at CT scanning [mm]',
        'CT scanning findings [Bilaterally normal=BN; Bilaterally abnormal=BA; Unilateral abnormality=UA]']
Query = np.zeros((1,6))
Prediction_type = ['Unilateral PA',
'Bilateral PA']
for i in range(len(ABPM_parameters)):
    String_to_print = 'Insert value of ' +ABPM_parameters[i]+' and press enter:\n'
    if i==3:
        if input(String_to_print) == 'Yes':
            Query[0,i] = 1
        else:
            Query[0,i] = 0
    elif i==4:
        if Query[0,3] == 0:
            pass
        else:
            Query[0,i] = input(String_to_print)
    elif i==5:
        inp = input(String_to_print)
        if inp == 'BN':
            Query[0,i] = 2
        elif inp == 'BA':
            Query[0,i] = 1
        else:
            Query[0,i] = 0
    else:
        Query[0,i] = input(String_to_print)

Prediction = loaded_model.predict(Query)
print ('------------')
print ('The patient is predicted as ' + Prediction_type[Prediction[0]-1])
